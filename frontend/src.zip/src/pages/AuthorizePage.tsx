import { useEffect, useState } from 'react'
import type { DemoCase } from '../types'
import { Icon } from '../components/Icon'
import { Button, Eyebrow, InfoNote } from '../components/Ui'

interface AuthorizePageProps {
  demoCase: DemoCase
  analyzing: boolean
  apiOnline: boolean | null
  error: string | null
  onBack: () => void
  onAnalyze: () => void
}

const connectors = [
  { id: 'bank', name: '工商银行账户流水', type: '核心', initial: true, icon: '/icons/ICBC.webp' },
  { id: 'unionpay', name: '银联流水', type: '核心', initial: true, icon: '/icons/UnionPay.png' },
  { id: 'alipay', name: '支付宝经营数据', type: '补充', initial: true, icon: '/icons/ALIPAY.png' },
  { id: 'wechat', name: '微信经营数据', type: '补充', initial: true, icon: '/icons/WeChat.jpg' },
  { id: 'meituan', name: '美团订单与评价', type: '补充', initial: true, icon: '/icons/Meituan.jpg' },
  { id: 'douyin', name: '抖音团购与社媒', type: '补充', initial: false, icon: '/icons/TikTok.jpg' },
  { id: 'xiaohongshu', name: '小红书口碑', type: '补充', initial: false, icon: '/icons/RedNote.jpg' },
  { id: 'enterprise', name: '公开工商信息', type: '核验', initial: true, icon: '/icons/Public-IB-Information.jpg' },
]

export function AuthorizePage({ demoCase, analyzing, apiOnline, error, onBack, onAnalyze }: AuthorizePageProps) {
  const [enabled, setEnabled] = useState(() => connectors.filter((item) => item.initial).map((item) => item.id))
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    if (!analyzing) {
      setProgress(0)
      return
    }
    const timer = window.setInterval(() => setProgress((value) => Math.min(92, value + 8)), 140)
    return () => window.clearInterval(timer)
  }, [analyzing])

  return (
    <main className="workflow page-shell">
      <div className="workflow__intro">
        <div>
          <Eyebrow>04 相关数据授权</Eyebrow>
          <p>温馨提示：工商银行可获得下述平台与信息库相关信息。我们充分尊重您的隐私，需要经过您授权才能获得相关平台数据。请您根据企业需求合理选择数据授权。注意：数据授权数量可能影响最终评判结果；我们会获取全平台公开信息。请谨慎选择。</p>
        </div>
        <div className={`backend-state ${apiOnline ? 'is-online' : 'is-offline'}`}><i /><span>{apiOnline === null ? '检查分析服务…' : apiOnline ? '后端服务在线' : '后端离线 · 将使用固定样例'}</span></div>
      </div>

      <div className="authorize-layout">
        <section className="connector-panel">
          <div className="panel-heading"><div><h2>数据授权明细</h2><p>已选择 {enabled.length} / {connectors.length} 项</p></div><Icon name="lock" /></div>
          <div className="connector-list">
            {connectors.map((item) => {
              const active = enabled.includes(item.id)
              return (
                <button key={item.id} className={active ? 'is-active' : ''} onClick={() => setEnabled((items) => active ? items.filter((id) => id !== item.id) : [...items, item.id])}>
                  <span className="connector-logo"><img src={item.icon} alt="" /></span>
                  <span><strong>{item.name}</strong><small>{item.type}数据 · 演示授权</small></span>
                  <i className="toggle"><b /></i>
                </button>
              )
            })}
          </div>
        </section>

        <section className="analysis-panel">
          <div className="analysis-panel__case"><span>测算场景</span><strong>{demoCase === 'normal' ? '正常授信样例' : '人工复核样例'}</strong></div>
          <div className={`analysis-core ${analyzing ? 'is-running' : ''}`}>
            <div className="analysis-core__mark"><Icon name={analyzing ? 'refresh' : 'spark'} size={34} /></div>
            <h2>{analyzing ? '正在汇总三类分析…' : '资料已准备完成'}</h2>
            <p>{analyzing ? '系统正在测算授信额度，并匹配后续消费政策建议。' : '请确认授权信息后进入测算。'}</p>
            {analyzing && <div className="progress-track"><span style={{ width: `${progress}%` }} /></div>}
            {analyzing && <small>{progress < 34 ? '正在计算经营特征' : progress < 68 ? '正在核查交易异常' : '正在生成现金情景'}</small>}
          </div>
          {error && <InfoNote tone="warning">{error} 已保留页面资料并切换到固定联调响应。</InfoNote>}
          <Button icon="arrow" onClick={onAnalyze} disabled={analyzing}>{analyzing ? '测算进行中…' : '点击进行授信额度测算与消费政策匹配'}</Button>
          <div className="analysis-contract"><Icon name="shield" /><span><strong>接口契约 v0.2.0</strong>POST /api/v1/ml/full-analysis</span></div>
        </section>
      </div>

      <div className="workflow__actions">
        <Button variant="ghost" onClick={onBack} disabled={analyzing}>上一页</Button>
      </div>
    </main>
  )
}
