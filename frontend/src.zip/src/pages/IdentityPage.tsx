import { useRef, useState } from 'react'
import type { ApplicationDraft } from '../types'
import { Icon } from '../components/Icon'
import { Button, Eyebrow, InfoNote } from '../components/Ui'

interface IdentityPageProps {
  value: ApplicationDraft
  onChange: (value: ApplicationDraft) => void
  onBack: () => void
  onNext: () => void
}

export function IdentityPage({ value, onChange, onBack, onNext }: IdentityPageProps) {
  const licenseInputRef = useRef<HTMLInputElement | null>(null)
  const [licenseFileName, setLicenseFileName] = useState('')
  const update = (key: keyof ApplicationDraft, next: string | number) => onChange({ ...value, [key]: next })
  const isComplete = value.merchantName && value.industry && value.legalName && value.legalPhone && value.contactName && value.contactPhone
  const industries = ['美容美发', '餐饮服务', '生活服务', '宠物服务', '教育培训', '其他服务']
  const provinces = ['上海市', '北京市', '广东省', '浙江省', '江苏省', '四川省']
  const cities = value.province === '上海市'
    ? ['上海市']
    : value.province === '北京市'
      ? ['北京市']
      : ['请选择城市', '省会城市', '地级市']

  return (
    <main className="workflow page-shell">
      <div className="workflow__intro workflow__intro--simple">
        <div>
          <Eyebrow>01 · 基本信息上传</Eyebrow>
          <p>主体、收款账户与开票信息的一致性会影响经营真实性判断，请按营业执照如实填写。</p>
        </div>
      </div>

      <div className="form-layout">
        <section className="form-card">
          <div className="form-section-title"><span>01</span><div><h2>企业基本信息</h2><p>带 <b>*</b> 为后续接入的必填资料</p></div></div>
          <div className="form-grid">
            <label className="field field--wide"><span>主体名称 <b>*</b></span><input value={value.merchantName} onChange={(e) => update('merchantName', e.target.value)} placeholder="与营业执照保持一致" /></label>
            <label className="field"><span>所属行业 <b>*</b></span><input list="industry-options" value={value.industry} onChange={(e) => update('industry', e.target.value)} placeholder="请选择或填写所属行业" /><datalist id="industry-options">{industries.map((item) => <option value={item} key={item} />)}</datalist></label>
            <label className="field"><span>统一社会信用代码</span><input value={value.socialCreditCode} onChange={(e) => update('socialCreditCode', e.target.value)} placeholder="18 位代码" /></label>
            <label className="field"><span>经营地址 · 省</span><select value={value.province} onChange={(e) => update('province', e.target.value)}>{provinces.map((item) => <option key={item}>{item}</option>)}</select></label>
            <label className="field"><span>经营地址 · 市</span><select value={value.city} onChange={(e) => update('city', e.target.value)}>{cities.map((item) => <option key={item}>{item}</option>)}</select></label>
            <label className="field field--wide"><span>详细地址</span><input value={value.address} onChange={(e) => update('address', e.target.value)} placeholder="请填写营业执照登记地址或实际经营详细地址" /></label>
          </div>
          <div className={`upload-zone ${licenseFileName ? 'is-selected' : ''}`}>
            <Icon name="upload" size={28} />
            <div><strong>营业执照</strong><span>{licenseFileName || '支持 PDF / JPG / PNG，单文件不超过 10MB'}</span></div>
            <input
              ref={licenseInputRef}
              className="visually-hidden-file"
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={(event) => setLicenseFileName(event.target.files?.[0]?.name || '')}
            />
            <button type="button" onClick={() => licenseInputRef.current?.click()}>
              {licenseFileName ? '重新选择' : '选择文件'}
            </button>
            <small>{licenseFileName ? '文件已在前端记录，等待后端上传解析接口接入。' : '文件解析服务尚待后端接入；当前页面保存填写状态。'}</small>
          </div>
        </section>

        <section className="form-card">
          <div className="form-section-title"><span>02</span><div><h2>法人及联系人</h2><p>用于身份核验与申请进度通知</p></div></div>
          <div className="form-grid">
            <label className="field"><span>法人姓名 <b>*</b></span><input value={value.legalName} onChange={(e) => update('legalName', e.target.value)} placeholder="请输入法人姓名" /></label>
            <label className="field"><span>法人手机号 <b>*</b></span><input value={value.legalPhone} onChange={(e) => update('legalPhone', e.target.value)} placeholder="11 位手机号" inputMode="tel" /></label>
            <label className="field field--wide"><span>法人身份证号</span><input value={value.legalIdNumber} onChange={(e) => update('legalIdNumber', e.target.value)} placeholder="请输入法人身份证号" /></label>
            <label className="field"><span>联系人姓名 <b>*</b></span><input value={value.contactName} onChange={(e) => update('contactName', e.target.value)} placeholder="请输入联系人姓名" /></label>
            <label className="field"><span>联系人手机号 <b>*</b></span><input value={value.contactPhone} onChange={(e) => update('contactPhone', e.target.value)} placeholder="11 位手机号" inputMode="tel" /></label>
            <label className="field field--wide"><span>联系人身份证号</span><input value={value.contactIdNumber} onChange={(e) => update('contactIdNumber', e.target.value)} placeholder="请输入联系人身份证号" /></label>
            <label className="field field--wide"><span>本次申请金额</span><div className="money-input"><b>¥</b><input value={value.requestedAmount} onChange={(e) => update('requestedAmount', Number(e.target.value))} type="number" min="0" step="10000" /></div><small>仅作为需求输入，建议额度由后端模型独立计算。</small></label>
          </div>
          <InfoNote tone="warning">请勿将“申请金额”理解为承诺额度。系统会结合分数、稳定性与承接能力返回建议额度。</InfoNote>
        </section>
      </div>

      <div className="workflow__actions">
        <Button variant="ghost" onClick={onBack}>上一页</Button>
        <Button icon="arrow" onClick={onNext} disabled={!isComplete}>下一页</Button>
      </div>
    </main>
  )
}
