import { useState } from 'react'
import { Icon, type IconName } from '../components/Icon'
import { Button, Eyebrow } from '../components/Ui'

interface DataPageProps {
  onBack: () => void
  onNext: () => void
}

const uploadGroups: Array<{
  id: string
  icon: IconName
  title: string
  description: string
  required: boolean
  hint: string
}> = [
  { id: 'cashflow', icon: 'database', title: '现金流量表', description: '请上传近6个月的现金流量表和近1年的总现金流量表（选填）', required: true, hint: '了解企业经营情况，预测资金缺口' },
  { id: 'statement', icon: 'document', title: '资产负债表', description: '请上传近1年的企业资产负债表；如开业未满1年，请上传最近一次的资产负债表', required: true, hint: '了解企业还款能力和经营稳定性' },
  { id: 'tax', icon: 'building', title: '纳税与开票资料', description: '近6个月的销售发票、采购发票及每个月的纳税申报信息', required: true, hint: '用于经营真实性交叉验证' },
  { id: 'plan', icon: 'spark', title: '经营计划', description: '未来三个月资本开支与还本付息安排', required: false, hint: '用于补充资金情景测算' },
]

export function DataPage({ onBack, onNext }: DataPageProps) {
  const [uploaded, setUploaded] = useState<string[]>(['cashflow', 'statement', 'tax'])
  const [fileNames, setFileNames] = useState<Record<string, string>>({})
  const markDemoReady = (id: string) => setUploaded((items) => items.includes(id) ? items : [...items, id])
  const handleFile = (id: string, fileName?: string) => {
    if (!fileName) return
    setFileNames((items) => ({ ...items, [id]: fileName }))
    markDemoReady(id)
  }
  const complete = uploadGroups.filter((item) => item.required).every((item) => uploaded.includes(item.id))

  return (
    <main className="workflow page-shell">
      <div className="workflow__intro workflow__intro--compact">
        <div>
          <Eyebrow>03 经营数据</Eyebrow>
        </div>
        <div className="completion-ring" style={{ '--progress': `${(uploaded.length / uploadGroups.length) * 360}deg` } as React.CSSProperties}>
          <strong>{uploaded.length}<small> / {uploadGroups.length}</small></strong><span>资料组</span>
        </div>
      </div>

      <section className="upload-grid">
        {uploadGroups.map((item, index) => {
          const isUploaded = uploaded.includes(item.id)
          const fileName = fileNames[item.id]
          return (
            <article className={`upload-card ${isUploaded ? 'is-complete' : ''}`} key={item.id}>
              <div className="upload-card__index">0{index + 1}</div>
              <div className="upload-card__icon"><Icon name={item.icon} size={24} /></div>
              <div className="upload-card__body">
                <div className="upload-card__title"><h2>{item.title}</h2><span className={item.required ? 'is-required' : ''}>{item.required ? '*' : '可选'}</span></div>
                <p>{item.description}</p><small>{item.hint}</small>
              </div>
              <div className="upload-card__actions">
                <label className="upload-action">
                  <Icon name={fileName ? 'check' : 'upload'} size={18} />
                  <span>{fileName || '选择文件'}</span>
                  <input
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls,.csv,.doc,.docx"
                    onChange={(event) => handleFile(item.id, event.target.files?.[0]?.name)}
                  />
                </label>
                <button type="button" onClick={() => markDemoReady(item.id)}>
                  <Icon name={isUploaded ? 'check' : 'database'} size={18} />
                  {isUploaded && !fileName ? '已使用演示数据' : '使用演示数据'}
                </button>
              </div>
            </article>
          )
        })}
      </section>

      <div className="workflow__actions">
        <Button variant="ghost" onClick={onBack}>上一页</Button>
        <Button icon="arrow" onClick={onNext} disabled={!complete}>下一页</Button>
      </div>
    </main>
  )
}
