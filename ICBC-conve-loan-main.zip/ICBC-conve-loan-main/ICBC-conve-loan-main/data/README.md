# Data

## `Data_Dictionary_Revised.xlsx`

当前开发基线为 `Data_Dictionary_Revised.xlsx`。该版本已包含 v5 口碑权重、评价数/订单数比交叉验证、人工审核规则 V09，以及税务合规人工审核规则 T01 的数据来源字段。

字段定义 + 评分规则 + 额度规则 + 人工审核规则，共9个sheet：

| Sheet | 内容 |
|---|---|
| Input_Data_Structural | 商户需提交/授权的原始结构化字段 |
| Operating_Structural | 由原始字段计算出的结构化中间变量与四个子评分公式 |
| Input_Unstructural | 商户需提交/授权的原始非结构化字段（评价/社媒/投诉） |
| operating unstructural | 非结构化中间变量与子评分公式 |
| Outputs | 报告输出字段（含AI智能解释模块） |
| 评分规则_打分卡 | 每个变量的打分区间和权重，可直接翻译成代码 |
| 额度映射规则 | 综合分→倍数、成长性扩张加成、最终额度公式 |
| 人工审核规则 | 一票否决（V01-V09）+ 税务合规 T01 + 低置信度转人工（L01-L04） |
| Consumption_Matching_Strategy | 消费场景匹配规则 |

## `Five_Testing_Merchants.xlsx`

5个覆盖不同画像的测试商户（优质稳定型/成长型/风险型/数据缺失型/疑似异常型），
每个商户的原始数据 + 精确计算的中间变量、子评分、综合分、额度、置信度、触发规则。
"预期输出对照表(最终版)" sheet是开发验收标准。

"测试商户总览" sheet 中曾记录的"刷好评"识别不足问题，已通过新版线上口碑权重和 V09 规则在后端 `v5_current` profile 中处理。

## `Structured/`

- `icbc_structured_tax_rules.db`：由原始数据字典和五商户结构化数据整理出的 SQLite 数据库，包含规则表、月度经营序列、财务快照、发票交叉验证、纳税合规字段和结构化评分结果。
- `icbc_structured_tax_rules_schema.sql`：上述 SQLite 的表结构。
- `structured_scoring_results.csv`：结构化模块的独立评分结果，保留用于数据审计和模块说明。

当前 FastAPI 主评分链路直接使用 JSON 请求体；税务合规字段已接入 `v5_current` 的 T01 人工审核规则，`legacy_acceptance` 仍保持旧验收口径。

## `Unstructured/`

非结构化 SQLite、CSV、DOCX 和词云图片均已按 `Five_Testing_Merchants.xlsx` 与后端 fixture 对齐：

- `icbc_unstructured_reviews.db`：五商户评价明细、关键词统计、分析结果和词云相对路径。
- `test_merchant_*_comments.csv`：每个商户的模拟评价明细，样本数、均分、负面占比与后端 fixture 对齐。
- `test_merchant_*.docx`：每个商户的非结构化分析摘要。
- `test_merchant_*_wordcloud.png`：词云图片；数据库中仅保存仓库内相对路径。

## `ml_simulated/`

- `transactions.json`：五商户 553 笔模拟交易，包含 M003/M005 的可解释异常注入。
- `cashflow_monthly.json`：五商户连续 12 个月现金流及未来三个月计划支出。

上述文件用于异常识别、资金缺口预测的开发与接口验收。它们不是银行真实数据，不能用于声称已经训练真实违约或欺诈模型；生成方法和限制见 `ml_simulated/README.md`。
