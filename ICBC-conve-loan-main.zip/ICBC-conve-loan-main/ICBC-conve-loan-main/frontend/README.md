# Frontend

当前目录先放置一个零依赖联调页，用于在正式 React/Next.js 前端完成前验证后端契约。

## 本地联调

先启动后端：

```powershell
cd backend
.\venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

再从仓库根目录启动静态服务：

```powershell
python -m http.server 5173
```

浏览器访问：

```text
http://127.0.0.1:5173/frontend/index.html
```

页面会读取 `docs/api_examples` 里的请求样例，并真实调用：

```text
POST http://127.0.0.1:8000/api/v1/ml/full-analysis
```

## 后续正式前端

建议使用 React 或 Next.js 初始化后，把 `app.js` 里的字段映射迁移到正式页面。

页面清单（对应开发文档要求的6个页面）：

1. 商户申请首页
2. 数据填写与上传页
3. 分析进度页
4. 授信与经营报告页
5. 消费促进方案页
6. 银行监控仪表盘
