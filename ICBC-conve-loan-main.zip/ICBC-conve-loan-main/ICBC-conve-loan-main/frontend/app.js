const API_BASE = "http://127.0.0.1:8000";
const NORMAL_REQUEST = "/docs/api_examples/full_analysis_normal_request.json";
const REVIEW_REQUEST = "/docs/api_examples/full_analysis_review_request.json";

const elements = {
  serviceStatus: document.querySelector("#serviceStatus"),
  overallRisk: document.querySelector("#overallRisk"),
  scoreValue: document.querySelector("#scoreValue"),
  limitValue: document.querySelector("#limitValue"),
  anomalyValue: document.querySelector("#anomalyValue"),
  decisionBadge: document.querySelector("#decisionBadge"),
  merchantName: document.querySelector("#merchantName"),
  gradeValue: document.querySelector("#gradeValue"),
  confidenceValue: document.querySelector("#confidenceValue"),
  pdStatus: document.querySelector("#pdStatus"),
  reviewCount: document.querySelector("#reviewCount"),
  reviewRules: document.querySelector("#reviewRules"),
  anomalyState: document.querySelector("#anomalyState"),
  anomalyRisk: document.querySelector("#anomalyRisk"),
  anomalyCodes: document.querySelector("#anomalyCodes"),
  evidenceCount: document.querySelector("#evidenceCount"),
  cashState: document.querySelector("#cashState"),
  p50Gap: document.querySelector("#p50Gap"),
  p90Gap: document.querySelector("#p90Gap"),
  cashRisk: document.querySelector("#cashRisk"),
  apiVersion: document.querySelector("#apiVersion"),
  warnings: document.querySelector("#warnings"),
};

function money(value) {
  if (value === null || value === undefined) return "--";
  return new Intl.NumberFormat("zh-CN", {
    style: "currency",
    currency: "CNY",
    maximumFractionDigits: 0,
  }).format(value);
}

function valueOrDash(value) {
  return value === null || value === undefined || value === "" ? "--" : value;
}

function riskClass(value) {
  const key = String(value || "").toLowerCase();
  if (key === "low") return "risk-low";
  if (key === "medium") return "risk-medium";
  if (key === "high") return "risk-high";
  if (key === "manual_review") return "risk-manual";
  return "";
}

function setStatus(ok, text) {
  elements.serviceStatus.innerHTML = "";
  const dot = document.createElement("span");
  dot.className = `dot ${ok ? "dot-ok" : "dot-error"}`;
  const label = document.createElement("span");
  label.textContent = text;
  elements.serviceStatus.append(dot, label);
}

async function checkHealth() {
  try {
    const response = await fetch(`${API_BASE}/health`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    setStatus(true, "后端在线");
  } catch (error) {
    setStatus(false, "后端未连接");
  }
}

async function loadRequest(path) {
  const response = await fetch(path);
  if (!response.ok) {
    throw new Error(`样例读取失败：${response.status}`);
  }
  return response.json();
}

async function runScenario(path, transform = (request) => request) {
  elements.overallRisk.textContent = "分析中";
  const request = transform(await loadRequest(path));
  const response = await fetch(`${API_BASE}/api/v1/ml/full-analysis`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`接口调用失败：${response.status} ${text}`);
  }

  render(await response.json());
}

function render(result) {
  const score = result.score;
  const anomaly = result.anomaly;
  const cashGap = result.cash_gap;
  const reviewRules = score.review_rules || [];
  const warnings = result.data_warnings || [];

  elements.overallRisk.textContent = result.overall_risk;
  elements.overallRisk.className = riskClass(result.overall_risk);
  elements.scoreValue.textContent = valueOrDash(score.operating_credit_score);
  elements.limitValue.textContent = money(score.limit?.recommended_limit);
  elements.anomalyValue.textContent = anomaly ? anomaly.anomaly_score : "--";
  elements.decisionBadge.textContent = score.decision;
  elements.merchantName.textContent = `${score.merchant_name}（${score.merchant_id}）`;
  elements.gradeValue.textContent = score.credit_grade;
  elements.confidenceValue.textContent = score.confidence;
  elements.pdStatus.textContent = `${score.pd_status} / ${score.pd_12m ?? "null"}`;
  elements.reviewCount.textContent = `${reviewRules.length} 条`;

  elements.reviewRules.innerHTML = "";
  if (reviewRules.length === 0) {
    const item = document.createElement("li");
    item.textContent = "未命中人工审核规则";
    elements.reviewRules.append(item);
  } else {
    reviewRules.forEach((rule) => {
      const item = document.createElement("li");
      item.innerHTML = `<strong>${rule.code}</strong>${rule.message}`;
      elements.reviewRules.append(item);
    });
  }

  elements.anomalyState.textContent = result.module_states.anomaly;
  elements.anomalyRisk.textContent = anomaly ? anomaly.risk_level : "--";
  elements.anomalyCodes.textContent = anomaly
    ? anomaly.reason_codes.join("、") || "--"
    : "--";
  elements.evidenceCount.textContent = anomaly
    ? `${anomaly.evidence_transaction_ids.length} 笔`
    : "--";

  elements.cashState.textContent = result.module_states.cash_gap;
  elements.p50Gap.textContent = cashGap ? money(cashGap.max_p50_funding_gap) : "--";
  elements.p90Gap.textContent = cashGap ? money(cashGap.max_p90_funding_gap) : "--";
  elements.cashRisk.textContent = cashGap ? cashGap.risk_level : "--";
  elements.apiVersion.textContent = result.api_version;

  elements.warnings.innerHTML = "";
  if (warnings.length === 0) {
    const item = document.createElement("li");
    item.textContent = "全部模块已运行";
    elements.warnings.append(item);
  } else {
    warnings.forEach((warning) => {
      const item = document.createElement("li");
      item.textContent = warning;
      elements.warnings.append(item);
    });
  }
}

function bindActions() {
  document.querySelector("#normalButton").addEventListener("click", () => {
    runScenario(NORMAL_REQUEST).catch((error) => {
      setStatus(false, error.message);
    });
  });
  document.querySelector("#reviewButton").addEventListener("click", () => {
    runScenario(REVIEW_REQUEST).catch((error) => {
      setStatus(false, error.message);
    });
  });
  document.querySelector("#missingAnomalyButton").addEventListener("click", () => {
    runScenario(REVIEW_REQUEST, (request) => ({ ...request, anomaly: null })).catch(
      (error) => {
        setStatus(false, error.message);
      },
    );
  });
  document.querySelector("#missingCashButton").addEventListener("click", () => {
    runScenario(REVIEW_REQUEST, (request) => ({ ...request, cash_gap: null })).catch(
      (error) => {
        setStatus(false, error.message);
      },
    );
  });
}

bindActions();
checkHealth();
runScenario(NORMAL_REQUEST).catch((error) => {
  setStatus(false, error.message);
});
